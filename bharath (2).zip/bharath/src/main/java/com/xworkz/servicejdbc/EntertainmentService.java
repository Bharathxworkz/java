package com.xworkz.servicejdbc;

import com.xworkz.jdbc.dto.Moviedto;

public interface EntertainmentService {

    void insertmovie(Moviedto moviedto);
}
