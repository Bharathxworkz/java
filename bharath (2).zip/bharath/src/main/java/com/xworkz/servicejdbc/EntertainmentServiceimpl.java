package com.xworkz.servicejdbc;

import com.xworkz.jdbc.dao.Entertaiment;
import com.xworkz.jdbc.dao.EntertamentImpl;
import com.xworkz.jdbc.dto.Moviedto;

public class EntertainmentServiceimpl implements EntertainmentService{
    @Override
    public void insertmovie(Moviedto moviedto) {

        if(moviedto!= null && moviedto.getName()!=null && !moviedto.getName().isEmpty()){
            Entertaiment entertaimentm= new EntertamentImpl();
            //dao
            entertaimentm.insertinto(moviedto);

        }else {
            System.out.println("plz once check given inputs somethings is empty");
        }
    }
}
