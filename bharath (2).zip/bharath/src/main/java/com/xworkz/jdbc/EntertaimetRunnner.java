package com.xworkz.jdbc;

import com.xworkz.jdbc.dao.Entertaiment;
import com.xworkz.jdbc.dao.EntertamentImpl;
import com.xworkz.jdbc.dto.Moviedto;
import com.xworkz.servicejdbc.EntertainmentService;
import com.xworkz.servicejdbc.EntertainmentServiceimpl;

public class EntertaimetRunnner {
    public static void main(String[] args) {
        EntertamentImpl entertament= new EntertamentImpl();

            Moviedto moviedto= new Moviedto();

        entertament.insertinto(moviedto);

        EntertainmentService entertainmentService= new EntertainmentServiceimpl();
        entertainmentService.insertmovie(moviedto);
    }
}
