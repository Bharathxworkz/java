package com.xworkz.jdbc.dao;

import com.xworkz.jdbc.dto.Moviedto;

public interface Entertaiment {

    void getNumberOfMOvies();



}
