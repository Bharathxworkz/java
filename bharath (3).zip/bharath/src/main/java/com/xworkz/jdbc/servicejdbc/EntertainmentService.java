package com.xworkz.jdbc.servicejdbc;

import com.xworkz.jdbc.dto.Moviedto;

public interface EntertainmentService {

    void getMovies();
}
