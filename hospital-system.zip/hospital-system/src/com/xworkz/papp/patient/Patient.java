package com.xworkz.papp.patient;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class  Patient {
    private int patientId;
    private  String patientName;
    private int age;
    private String address;



}
