package com.xworkz.encapulationapp;

public class Data {

    private String name;
    private int id;
    private  String profesinal;
    private  int salary;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setProfesinal(String profesinal) {
        this.profesinal = profesinal;

    }

    public String getProfesinal() {
        return profesinal;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }
}
