package com.xworkz.patientapp.hospital;

public class HopeHospital {
}
