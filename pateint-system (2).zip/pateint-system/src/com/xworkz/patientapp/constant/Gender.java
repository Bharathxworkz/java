package com.xworkz.patientapp.constant;

public class Gender {
    public static String MAlE= "Male";
}
