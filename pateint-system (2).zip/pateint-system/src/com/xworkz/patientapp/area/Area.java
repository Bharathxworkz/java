package com.xworkz.patientapp.area;

public class Area {

   public String areaName;
  public   String streetName;
   public int streetNo;

    public  void getAreadetails()
    {
        System.out.println("The are Name:"+areaName);
        System.out.println("The streName:" + streetName);
        System.out.println("the streetNo:"+ streetNo);
    }


}
