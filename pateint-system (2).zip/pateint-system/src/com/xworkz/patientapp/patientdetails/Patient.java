package com.xworkz.patientapp.patientdetails;

import com.sun.org.apache.xpath.internal.objects.XString;
import com.xworkz.patientapp.address.Address;
import com.xworkz.patientapp.constant.Gender;

public class Patient {
   public static String hospitalName;
   public String name;
   public String age;
  public   String disease;
  public String gender;
    Address address ;

      public Patient(Address address){
           this.address      =    address;
      }
    public void getPatientDetailsAndAddress(){
        System.out.println("The name of patient:" +this.name);
        System.out.println("patient age :"+this. age);
        System.out.println("The patient suffering from :"+this.disease);
        System.out.println("Thegender of patient:"+this.gender);
        this.address.getAddressDetails();
    }



}
