package org.xworkz.spring.patientapp.hospital;

public class BmsHospital {
    public static String cityName;
}
