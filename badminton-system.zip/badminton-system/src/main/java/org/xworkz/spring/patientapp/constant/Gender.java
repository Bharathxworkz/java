package org.xworkz.spring.patientapp.constant;

import org.springframework.stereotype.Component;

@Component
public class Gender {
    public static String MAlE= "Male";
}
