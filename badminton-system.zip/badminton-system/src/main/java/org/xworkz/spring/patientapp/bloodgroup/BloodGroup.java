package org.xworkz.spring.patientapp.bloodgroup;

import org.springframework.stereotype.Component;

@Component
public enum BloodGroup {
    OPOSITIVE,BPOSITIVE;
}
