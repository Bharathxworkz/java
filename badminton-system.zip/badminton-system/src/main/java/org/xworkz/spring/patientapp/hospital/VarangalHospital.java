package org.xworkz.spring.patientapp.hospital;

public class VarangalHospital {
}
