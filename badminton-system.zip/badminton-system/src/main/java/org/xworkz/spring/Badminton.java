package org.xworkz.spring;

import org.springframework.stereotype.Component;

@Component
public class Badminton {
    public String playerName;
    public  int palyerNumber;

}
