package org.xworkz.spring.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "org.xworkz.spring")
public class SpringConfiguartion {
    public SpringConfiguartion(){

    }
}
