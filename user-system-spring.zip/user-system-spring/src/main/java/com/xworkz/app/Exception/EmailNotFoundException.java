package com.xworkz.app.Exception;

public class EmailNotFoundException  extends RuntimeException{
    public EmailNotFoundException(String message){
        System.out.println(message);

    }

}
