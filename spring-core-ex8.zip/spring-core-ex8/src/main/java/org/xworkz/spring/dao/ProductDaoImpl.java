package org.xworkz.spring.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.xworkz.spring.dto.ProductDto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

@Component
public class ProductDaoImpl implements ProductDao {

    @Autowired
    private EntityManagerFactory factory;

    @Override
    public boolean save(ProductDto productDto) {
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(productDto);
        entityManager.getTransaction().commit();
        entityManager.close();
        return true;
    }

    @Override
    public void UpdateUser(ProductDto productDto) {
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.merge(productDto);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    @Override
    public boolean deleteUserById(int id) {
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();
        ProductDto product = entityManager.find(ProductDto.class, id);
        if (product != null) {
            entityManager.remove(product);
            entityManager.getTransaction().commit();
            entityManager.close();
            return true;
        }
        entityManager.getTransaction().rollback();
        entityManager.close();
        return false;
    }

    @Override
    public ProductDto getUserbyId(int id) {
        EntityManager entityManager = factory.createEntityManager();
        ProductDto product = entityManager.find(ProductDto.class, id);
        entityManager.close();
        return product;
    }
}
