public class CheckVowelsAndConsonants {
    public static void main(String[] args)
    {

        char c = 'g';

        //checking for vowels
        if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
        {
            System.out.println(c + " is a vowel ");  // condition true input is vowel
        }
        else
        {
            System.out.println(c + " is a consonant ");  // condition true input is consonant
        }

    }


}
