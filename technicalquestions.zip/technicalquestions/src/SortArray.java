import java.util.Arrays;

public class SortArray {
    public static void main(String[] args) {
        int[] arr = {5, 3, 8, 1, 2};

        Arrays.sort(arr); // Sorting the array

        System.out.println("Sorted Array: " + Arrays.toString(arr));
    }
}
