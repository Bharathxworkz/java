package com.xworkz.patientapp.hospital;

public class BmsHospital {
    public static String cityName;
}
