package com.xworkz.patientapp.bloodgroup;

public enum BloodGroup {
    OPOSITIVE,BPOSITIVE;
}
