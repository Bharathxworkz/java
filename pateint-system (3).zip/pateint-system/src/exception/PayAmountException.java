package exception;

public class PayAmountException extends RuntimeException{
    public PayAmountException(String erorMessage){

        System.out.println(erorMessage);

    }
}
