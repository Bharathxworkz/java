package com.xworkz.service;

import com.xworkz.dto.NyearDto;
import com.xworkz.entity.NyearEntity;

public interface NyearService {
    boolean save(NyearDto dto);

   NyearEntity getDtoByEmail(String email);



    void updatePasswordByEmail(String email, String newPassword);
}
