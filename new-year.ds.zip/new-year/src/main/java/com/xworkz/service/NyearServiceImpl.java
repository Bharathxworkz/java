package com.xworkz.service;

import com.xworkz.dto.NyearDto;
import com.xworkz.entity.NyearEntity;
import com.xworkz.repository.NyearRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class NyearServiceImpl implements NyearService{

    @Autowired
     private NyearRepository nyearRepository;
    @Override
    public boolean save(NyearDto dto) {

        NyearEntity entity= new NyearEntity();
        dto.setCreatedBy(dto.getFirstName());
        dto.setCreatedTime(LocalDate.now());
        BeanUtils.copyProperties(dto,entity);
        System.out.println(entity);
        nyearRepository.save(entity);
        return false;
    }

    @Override
    public NyearEntity getDtoByEmail(String email) {
        return  nyearRepository.getDtoByEmail( email);
    }

    @Override
    public void updatePasswordByEmail(String email, String newPassword) {
        nyearRepository.updatePasswordByEmail( email, newPassword);
    }




}
