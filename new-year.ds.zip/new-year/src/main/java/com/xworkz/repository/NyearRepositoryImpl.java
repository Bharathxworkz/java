package com.xworkz.repository;

import com.xworkz.dto.NyearDto;
import com.xworkz.entity.NyearEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

@Repository
public class NyearRepositoryImpl implements NyearRepository {
    @Autowired
    EntityManagerFactory factory;

    @Override
    public void save(NyearEntity entity) {
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(entity);
        entityManager.getTransaction().commit();

    }

    @Override
    public NyearEntity getDtoByEmail(String email) {
        return (NyearEntity) factory.createEntityManager()
                .createQuery("Select user from NyearEntity user where user.email = :email")
                .setParameter("email", email)
                .getSingleResult();
    }

    @Override
    public void updatePasswordByEmail(String email, String newPassword) {
        EntityManager entityManager = factory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();

        try {
            transaction.begin();

            int updated = entityManager.createQuery(
                            "UPDATE NyearEntity user SET user.password = :newPassword WHERE user.email = :email")
                    .setParameter("newPassword", newPassword)
                    .setParameter("email", email)
                    .executeUpdate();

            if (updated == 0) {
                throw new RuntimeException("No user found with the given email.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            throw new RuntimeException("Failed to update password: " + e.getMessage());
        } finally {
            entityManager.close();
        }
    }



}