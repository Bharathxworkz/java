package com.xworkz.repository;

import com.xworkz.dto.NyearDto;
import com.xworkz.entity.NyearEntity;

import java.util.List;

public interface NyearRepository {
    void save(NyearEntity entity);

   NyearEntity  getDtoByEmail(String email);

    void updatePasswordByEmail(String email, String newPassword);
}
