package com.xworkz.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class PageController {

    @GetMapping("Registration")
    public String getpages() {
        return "Registration";
    }

    @GetMapping("signin")
    public String getpage() {
        return "signin";
    }

    @GetMapping("forgot")
    public String forgotpasswordpage() {
        return "forgetpassword";
    }
    @GetMapping("test")
    public String mainpage() {
        return "test";
    }
}
