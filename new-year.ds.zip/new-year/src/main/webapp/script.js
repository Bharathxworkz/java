 <script>
            const form = document.getElementById('registrationForm');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirmPassword');
            const passwordError = document.getElementById('passwordError');

            form.addEventListener('submit', (e) => {
                if (password.value !== confirmPassword.value) {
                    e.preventDefault(); // Prevent form submission
                    passwordError.style.display = 'block'; // Show error message
                } else {
                    passwordError.style.display = 'none'; // Hide error message
                }
            });
        </script>