package com.xworkz.app.constants;

import lombok.Getter;

@Getter
public enum ServiceConstant {
    FILE_PATH("E://userNewYear/"),FROM_EMAIL("shettyraksha659@gmail.com"),FROM_NAME("RAKSHA SHETTY"),PASSWORD("dyfc ubba gqum koei");

    private String path;

    private ServiceConstant(String path){
        this.path=path;
    }
}
