package com.xworks.formsystem.servlets.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/response")
public class ResponseServlet extends HttpServlet {
}
